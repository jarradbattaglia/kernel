// First new GL program
// Just makes a red triangle

#include "Angel.h"
const int CircleNumPoints = 360;
const float radius = .2;
const float box1X = .6;
const float box1Y = .4;
const float box2X = .5;
const float box2Y = .3;
const float box3X = .4;
const float box3Y = .2;
const float box4X = .3;
const float box4Y = .1;
const float box5X = .2;
const float box5Y = 0.0;
const float box6X = .1;
const float box6Y = -0.1;

//--------------------------------------------------------------------------

void
init( void )
{
    vec2 vectors[747];
    vec3 colors[747];
    float degToRad = 3.14/180;
    for(int i=0;i<360;i++) {
        vectors[i] = vec2((cos(i)*radius)+.7,sin(i)*radius+.7);
        float variable = -cos(i*degToRad*.4);
        colors[i] = vec3(variable,0.0,0.0);
    }
    //draw ellipse
    for(int i=360;i<720;i++) {
        vectors[i] = vec2(cos(i)*radius-.7,(sin(i)*radius)*.60+.7);
        colors[i] = vec3(1.0,0.0,0.0);
    }
    vectors[720] = vec2(0.0,1.0);
    colors[720]  =vec3(1.0,0.0,0.0);
    vectors[721] = vec2(0.3,0.5);
    colors[721]  =vec3(0.0,0.0,1.0);
    colors[722]  =vec3(0.0,1.0,0.0);
    vectors[722] = vec2(-0.3,0.5);
    
    //draw box one
    vectors[723] = vec2(box1X,box1Y);
    vectors[724] = vec2(-box1X,box1Y);
    vectors[725] = vec2(box1X,-0.8);
    vectors[726] = vec2(-box1X,-0.8);
    colors[723]  =vec3(1.0,1.0,1.0);
    colors[724]  =vec3(1.0,1.0,1.0);
    colors[725]  =vec3(1.0,1.0,1.0);
    colors[726]  =vec3(1.0,1.0,1.0);

    //draw box 2
    vectors[727] = vec2(box2X,box2Y);
    vectors[728] = vec2(-box2X,box2Y);
    vectors[729] = vec2(box2X,-0.7);
    vectors[730] = vec2(-box2X,-0.7);
    colors[727]  = vec3(0.0,0.0,0.0);
    colors[728]  = vec3(0.0,0.0,0.0);
    colors[729]  = vec3(0.0,0.0,0.0);
    colors[730]  = vec3(0.0,0.0,0.0);

    //draw box 3
    vectors[731] = vec2(box3X,box3Y);
    vectors[732] = vec2(-box3X,box3Y);
    vectors[733] = vec2(box3X,-0.6);
    vectors[734] = vec2(-box3X,-0.6);
    colors[731]  =vec3(1.0,1.0,1.0);
    colors[732]  =vec3(1.0,1.0,1.0);
    colors[733]  =vec3(1.0,1.0,1.0);
    colors[734]  =vec3(1.0,1.0,1.0);
    //draw box 4
    vectors[735] = vec2(box4X,box4Y);
    vectors[736] = vec2(-box4X,box4Y);
    vectors[737] = vec2(box4X,-0.5);
    vectors[738] = vec2(-box4X,-0.5);
    colors[735]  = vec3(0.0,0.0,0.0);
    colors[736]  =vec3(0.0,0.0,0.0);
    colors[737]  =vec3(0.0,0.0,0.0);
    colors[738]  =vec3(0.0,0.0,0.0);
    //draw box 5
    vectors[739] = vec2(box5X,box5Y);
    vectors[740] = vec2(-box5X,box5Y);
    vectors[741] = vec2(box5X,-0.4);
    vectors[742] = vec2(-box5X,-0.4);
    colors[739]  =vec3(1.0,1.0,1.0);
    colors[740]  =vec3(1.0,1.0,1.0);
    colors[741]  =vec3(1.0,1.0,1.0);
    colors[742]  =vec3(1.0,1.0,1.0);
    //draw box 6
    vectors[743] = vec2(box6X,box6Y);
    vectors[744] = vec2(-box6X,box6Y);
    vectors[745] = vec2(box6X,-0.3);
    vectors[746] = vec2(-box6X,-0.3);
    colors[743]  =vec3(0.0,0.0,0.0);
    colors[744]  =vec3(0.0,0.0,0.0);
    colors[745]  =vec3(0.0,0.0,0.0);
    colors[746]  =vec3(0.0,0.0,0.0);

    // Create a vertex array object
    GLuint vao[1];
    glGenVertexArrays( 1, vao );
    glBindVertexArray( vao[1] );
    

    // Create and initialize a buffer object
    GLuint buffer;
    glGenBuffers( 1, &buffer );
    glBindBuffer( GL_ARRAY_BUFFER, buffer );
    glBufferData( GL_ARRAY_BUFFER, sizeof(vectors) + sizeof(colors), NULL, GL_STATIC_DRAW );
    glBufferSubData(GL_ARRAY_BUFFER,0,sizeof(vectors),vectors);
    glBufferSubData(GL_ARRAY_BUFFER,sizeof(vectors),sizeof(colors),colors);
// Load shaders and use the resulting shader program
    GLuint program = InitShader( "vshader21.glsl", "fshader21.glsl" );
    glUseProgram( program );

    // Initialize the vertex position attribute from the vertex shader
    GLuint loc = glGetAttribLocation( program, "vPosition" );
    glEnableVertexAttribArray( loc );
    glVertexAttribPointer( loc, 2, GL_FLOAT, GL_FALSE, 0,BUFFER_OFFSET(0) );
    GLuint loc2 = glGetAttribLocation(program,"vColor");
    glEnableVertexAttribArray(loc2);
    glVertexAttribPointer(loc2,3,GL_FLOAT,GL_FALSE,0,BUFFER_OFFSET(sizeof(vectors)));
    
    glClearColor( 0.0, 0.0, 0.0, 0.0 ); // black background
}

//----------------------------------------------------------------------------

void drawBox(int arrayLoc) {
    glDrawArrays(GL_TRIANGLE_STRIP,arrayLoc,4);
}

void
display( void )
{
    glClear( GL_COLOR_BUFFER_BIT );     // clear the window
    glDrawArrays( GL_TRIANGLE_FAN, 0, 360 );    // draw the points for circle
    glDrawArrays(GL_TRIANGLE_FAN,360,CircleNumPoints);
    glDrawArrays(GL_TRIANGLES,720,3);
    
    //draw the six boxes over each other
    drawBox(723);
    drawBox(727);
    drawBox(731);
    drawBox(735);
    drawBox(739);
    drawBox(743);
    
    glFlush();
}

//----------------------------------------------------------------------------

void
keyboard( unsigned char key, int x, int y )
{
    switch ( key ) {
    case 033:
        exit( EXIT_SUCCESS );
        break;
    }
}

//----------------------------------------------------------------------------

int
main( int argc, char **argv )
{
    glutInit( &argc, argv );
    glutInitDisplayMode( GLUT_RGBA );
    glutInitWindowSize( 500, 500 );

    glutCreateWindow( "Assignment 2" );
    glewExperimental=GL_TRUE; 
    glewInit();    
    init();

    glutDisplayFunc( display );
    glutKeyboardFunc( keyboard );

    glutMainLoop();
    return 0;
}
